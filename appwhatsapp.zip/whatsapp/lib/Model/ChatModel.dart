class ChatModel {
  String name;
  String time;
  String telefone;
  ChatModel({required this.name, required this.time, required this.telefone});
}